from flask import Flask, render_template, request, jsonify
import pickle
from keras.models import load_model
from keras import optree
import numpy as np


app = Flask(__name__)

# Load the saved model and data
with open('words.pkl', 'rb') as f:
    worlds = pickle.load(f)

with open('classes.pkl', 'rb') as f:
    classes = pickle.load(f)

model = load_model('chatbot_model.h5')

def preprocess_message(message):
    # Implement your preprocessing steps
    # Convert the message to model input
    return np.array([...])  # Your processed input here

def predict_response(message):
    processed_message = preprocess_message(message)
    predictions = model.predict(processed_message)
    return classes[np.argmax(predictions)]  # Modify based on your response handling

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_message = request.form['message']
    response = predict_response(user_message)
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)
