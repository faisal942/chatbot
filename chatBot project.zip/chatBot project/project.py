import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Define building dimensions
building_width = 100
building_height = 60

# Dead spot coordinates and dimensions
dead_spot_x, dead_spot_y = 30, 20
dead_spot_width, dead_spot_height = 10, 15

# WiFi Access Points and coverage radius
access_points = [
    (15, 10, 15),    # (x, y, radius)
    (50, 10, 15),
    (85, 10, 15),
    (25, 45, 15),
    (75, 45, 15)
]

# Plotting the building floor plan
fig, ax = plt.subplots()
ax.set_xlim(0, building_width)
ax.set_ylim(0, building_height)
plt.gca().set_aspect('equal', adjustable='box')

# Draw the dead spot area
dead_spot = patches.Rectangle((dead_spot_x, dead_spot_y), dead_spot_width, dead_spot_height,
                              linewidth=1, edgecolor='r', facecolor='red', label="Dead Spot")
ax.add_patch(dead_spot)

# Plot each WiFi access point and its coverage area
for x, y, radius in access_points:
    wifi_coverage = plt.Circle((x, y), radius, color='blue', alpha=0.3)
    ax.add_patch(wifi_coverage)
    plt.plot(x, y, 'bo')  # Access point location

# Labels and legend
plt.title("Building Floor Plan with WiFi Access Points and Dead Spot")
plt.xlabel("Width")
plt.ylabel("Height")
plt.legend(handles=[dead_spot], loc="upper right")

# Display the plot
plt.show()
