document.getElementById("send-btn").addEventListener("click", function () {
  const userInput = document.getElementById("user-input").value;

  // Display user message
  const chatOutput = document.getElementById("chat-output");
  const userMessage = document.createElement("div");
  userMessage.classList.add("message");
  userMessage.textContent = "You: " + userInput;
  chatOutput.appendChild(userMessage);

  // Send user message to Flask backend
  fetch("/get-response", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ message: userInput }),
  })
    .then((response) => response.json())
    .then((data) => {
      const botMessage = document.createElement("div");
      botMessage.classList.add("message");
      botMessage.textContent = "Bot: " + data.response;
      chatOutput.appendChild(botMessage);

      // Scroll chat output to the bottom
      chatOutput.scrollTop = chatOutput.scrollHeight;
    });

  // Clear input field
  document.getElementById("user-input").value = "";
});
